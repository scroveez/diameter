#!/usr/bin/perl
# -*- mode: Perl -*-
# digipass.pl
#
# Command line script for manipulating Digipass token data in an SQL or LDAP database
# intended for integration with Radiator etc.
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2004-2006 Open System Consultants
# $Id: digipass.pl,v 1.7 2007/07/13 00:31:36 mikem Exp $

require "newgetopt.pl";
use Authen::Digipass;
use strict;
my %ldapvalues;
my @options =
    (
     'h',                   # Print usage
     'v',                   # Verbose
     'd',                   # Debug
     'n',                   # Dont actually update the database

     # SQL database flags
     'dbsource=s',
     'dbusername=s',
     'dbauth=s',
     'table=s',

     # LDAP database flags (mostly compatible with ldap* command line flags)
     'ldap',                # Enable LDAP
     'D=s',                 # LDAP binddn
     'w=s',                 # LDAP bind password
     'p=i',                 # LDAP server port
     'host=s',              # LDAP server host (-h in ldapsearch etc)
     'b=s',                 # LDAP Search base
     'P=i',                 # LDAP Protocol version
     's=s',                 # LDAP search scope
     'objectclass=s',       # Additional objectClass for generated entry (separated with ,)
     'setldapvalue=s' => \%ldapvalues,        # Initial values for LDAP attribute (attr=value)

     'importkey=s',         # Key for importing tokens from a file
     'app=s',               # The name of the Digipass application to use. Spaces are important
     'f',                   # Force import to insert, even if it already exists
     'syncwindow=n',
     );

# Use DIGIPASS_PL_ARGS from environment
push(@ARGV, split(/\s+/, $ENV{DIGIPASS_PL_ARGS}));

&NGetOpt(@options) || &usage;
&usage if $main::opt_h;

# Default values for command line options
my $dbsource   = $main::opt_dbsource   || 'dbi:mysql:radius';
my $dbusername = $main::opt_dbusername || 'mikem';
my $dbauth     = $main::opt_dbauth     || 'fred';

my $ldaphost   = $main::opt_host       || 'localhost';
my $ldapport   = $main::opt_p          || 389;
my $ldapauthdn = $main::opt_D          || 'cn=Manager, dc=example, dc=com';
my $ldapauthpw = $main::opt_w          || 'secret';
my $ldapversion = $main::opt_P         || 3;
my $ldapbasedn = $main::opt_b          || 'dc=example, dc=com';
my $ldapscope  = $main::opt_s          || 'sub';
my $ldapobjectclass = $main::opt_objectclass || undef;

# Build the objectclass attributes
my @objectClasses = ('top', 'oscDigipassToken');
if ($ldapobjectclass) {
    foreach my $obj (split(/,/, $ldapobjectclass)) {
        push(@objectClasses, $obj);
    }
}

my $importkey  = $main::opt_importkey  || '11111111111111111111111111111111'; # For importing
my $requestapp = $main::opt_app        || 'APPL 1';
$requestapp =~ s/\s*$//; # Makes it easier to select an app

my $syncwindow = $main::opt_syncwindow || 6;
my $table      = $main::opt_table      || 'TBL_VASCODP';

my $dbh; # If we are connected to SQL
my $ld;  # If we are connected to LDAP
db_connect() or exit 1;

# Intialise the kernel parameters that Authen::Digipass requires for most calls.
my $kparms = Authen::Digipass::KernelParms->new(SyncWindow => $syncwindow);

# Command despatch table. Key must be lowercase
my %commands =
    (
     'import'               => \&import,
     'list'                 => \&listAll,
     'reset'                => \&resetData,
     'resetstaticpassword'  => \&resetStaticPassword,
     'changestaticpassword' => \&changeStaticPassword,
     'verify'               => \&verify,
     'assign'               => \&assign,
     'unlock'               => \&unlock,
     'info'                 => \&info,
     'help'                 => \&usage,
     );

# Despatch the command, case insensitve
my $command = lc shift @ARGV;
usage() unless exists $commands{$command};
&{$commands{$command}}();

sub usage
{
    print "usage: $0 [-h] [-d] [-v] [-n] [-f]
  [-importkey nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn] [-app appname]
  [-syncwindow hours]
SQL flags:
  [-dbsource dbi:db:etc] [-dbusername username] [-dbauth password]
LDAP flags:
  -ldap [-D authbinddn] [-w authpassword] [-host hostname] [-p port]
        [-b baseDN] [-P 2|3] [-objectclass class,class...] [-setldapvalue attr=value]
  command arg arg ...

Commands:
    import file file ...
    list
    reset serialno serialno .... 
    resetstaticpassword serialno serialno .... 
    changestaticpassword serialno newpin
    verify serialno password
    assign serialno [username]
    unlock serialno tokencode
    info serialno serialno ....
  \n";
    exit;
}


#####################################################################
# Import all the tokens from a number of files in DPX format
sub import
{
    usage() unless @ARGV; # Need filenames

    foreach (@ARGV)
    {
	print "Starting import of tokens from from file '$_' with key $importkey\n" if $main::opt_v;
	my ($ret, $handle, $appl_count, $appl_names, $token_count);
	my $ret = Authen::Digipass::AAL2DPXInit($handle, $_, $importkey,  $appl_count, $appl_names, $token_count);
	if ($ret != 0)
	{
	    # Open failed
	    my $err = Authen::Digipass::AAL2DPXGetErrorMsg($ret);
	    print STDERR "Error with init file '$_': $err\n";
	    next;
	}
	print "found $token_count tokens with $appl_count applications: ($appl_names)\n", if $main::opt_v;

	# Find out which app to import
	my @apps = unpack('a12 a12 a12 a12 a12 a12 a12 a12', $appl_names); # up to 8 x 12 byte app names
	splice(@apps, $appl_count);
	my $easyappnames = join(', ', map {"'$_'"} @apps);
	my $thisapp;
	if ($appl_count == 1)
	{
	    $thisapp = $apps[0];
	}
	else
	{
	    # Choose the app based on the default app name or the -app argument
	    my $i;
	    for ($i = 0; $i < $appl_count; $i++)
	    {
		# Strip trailing whitespace from the applicaiton name
		my $strippedapp = $apps[$i];
		$strippedapp =~ s/\s*$//;

		if ($strippedapp eq $requestapp)
		{
		    # This is the app to import
		    $thisapp = $apps[$i];
		}
	    }
	    if (!defined $thisapp)
	    {
		print STDERR "Application $requestapp not available for importing from this token file.\nThe following applications are available: $easyappnames.\nUse -app to specify which application to import\n";
		next;
	    }
	}

	my ($i, $serial, $type, $algo_type, $data);
	for ($i = 0; $i < $token_count; $i++)
	{
	    $ret = Authen::Digipass::AAL2DPXGetToken($handle, $kparms, $thisapp, $serial, $type, $algo_type, $data);
	    if ($ret < 0)
	    {
		print STDERR "Could not get token for application '$thisapp': " . Authen::Digipass::AAL2DPXGetErrorMsg($ret) . "\n";
		next;
	    }
	    print "Read token $serial, $type, $algo_type, $data\n" if $main::opt_v;

	    # Strip trailing whitespace from the serial nuber
	    $serial =~ s/\s*$//;

	    if (!db_insert_or_replace($serial, $type, $algo_type, $data))
	    {
		print STDERR "insert into database for Digipass '$serial' failed\n";
		next;
	    }

	    print "imported '$serial'\n";
	}
    }
}

#####################################################################
# Reset tokens
sub resetData
{
    usage() unless @ARGV; # Need serial

    foreach (@ARGV)
    {
	my $serial = normaliseSerial($_);
	my ($key, $data) = db_get($serial);

	if (defined $data)
	{
	    my $ret = Authen::Digipass::AAL2ResetTokenInfo($data, $kparms);
	    if ($ret != 0)
	    {
		my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
		print STDERR "Could not ResetTokenInfo for Digipass $serial: $err\n";
	    }
	    else
	    {
		db_update($key, $data);
	    }
	}
	else
	{
	    print STDERR "Could not reset '$serial': no such record in database\n";
	}
    }
}

#####################################################################
# Reset a tokens static password
sub resetStaticPassword
{
    usage() unless @ARGV; # Need serial

    foreach (@ARGV)
    {
	my $serial = normaliseSerial($_);
	my ($key, $data) = db_get($serial);
	if (defined $data)
	{
	    my $ret = Authen::Digipass::AAL2ResetStaticPassword($data, $kparms);
	    if ($ret != 0)
	    {
		my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
		print STDERR "Could not ResetStaticPassword for Digipass $serial: $err\n";
	    }
	    else
	    {
		db_update($key, $data);
	    }
	}
	else
	{
	    print STDERR "Could not reset '$serial': no such record in database\n";
	}
    }
}

#####################################################################
# Reset a tokens static password
sub changeStaticPassword
{
    usage() unless @ARGV >= 2; # Need serial and new password

    my $serial = normaliseSerial($ARGV[0]);
    my ($key, $data) = db_get($serial);
    if (defined $data)
    {
	my $ret = Authen::Digipass::AAL2ChangeStaticPassword($data, $kparms, $ARGV[1], $ARGV[1]);
	if ($ret != 0)
	{
	    my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
	    print STDERR "Could not ChangeStaticPassword for Digipass $serial: $err\n";
	}
	else
	{
	    db_update($key, $data);
	}
    }
    else
    {
	print STDERR "Could not cgangestaticpassword '$serial': no such record in database\n";
    }
}

#####################################################################
# Reset get the unlock code for a locked token
sub unlock
{
    usage() unless @ARGV >= 2; # Need serial and new password

    my $serial = normaliseSerial($ARGV[0]);
    my ($key, $data) = db_get($serial);
    if (defined $data)
    {
	my $unlockcode;
	my $ret = Authen::Digipass::AAL2Unlock($data, $kparms, $ARGV[1], $unlockcode);
	if ($ret != 0)
	{
	    my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
	    print STDERR "Could not get Unlock code for Digipass $serial: $err\n";
	}
	else
	{
	    print "Unlock code for $ARGV[0]: $unlockcode\n";

	    db_update($key, $data);
	}
    }
    else
    {
	print STDERR "Could not unlock '$serial': no such record in database\n";
    }
}
#
####################################################################
# Verify password
sub verify
{
    usage() unless @ARGV >= 2; # Need serial and password

    my $serial = normaliseSerial($ARGV[0]);
    my ($key, $data) = db_get($serial);
    if (defined $data)
    {
	my $ret = Authen::Digipass::AAL2VerifyPassword($data, $kparms, $ARGV[1], $ARGV[1]);
	if ($ret != 0)
	{
	    my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
	    print STDERR "Could not VerifyPassword for Digipass $serial: $err\n";
	}
	else
	{
	    db_update($key, $data);
	    print "Password OK\n";
	}
    }
    else
    {
	print STDERR "Could not verify '$serial': no such record in database\n";
    }
}

#####################################################################
# Print the data for one token record
# printOne(serial, user, tokentype, algotype, data)
sub printOne
{
    print join("\t", @_) . "\n";
}

#####################################################################
# List all tokens in the database
sub listAll
{
    db_iterate(\&printOne);
}

#####################################################################
# Assign a token to a username
sub assign
{
    usage() unless @ARGV >= 1; # Need serial at least

    my $serial = normaliseSerial($ARGV[0]);
    my ($key, $data) = db_get($serial);
    if (defined $data)
    {
	my $name = $ARGV[1];
	# Deassign any other tokens already assigned to that name
	db_deassign($name)
	    if defined $name;
	db_assign($key, $name);
    }
    else
    {
	print STDERR "Could not assign '$serial': no such record in database\n";
    }
}

#####################################################################
# Info about tokens
sub info
{
    usage() unless @ARGV; # Need serial

    foreach (@ARGV)
    {
	my $serial = normaliseSerial($_);
	my ($key, $data) = db_get($serial);
	if (defined $data)
	{
	    my %info;
	    my $ret = Authen::Digipass::AAL2GetTokenInfoEx($data, $kparms, \%info);
	    $ret = Authen::Digipass::AAL2GetTokenInfo($data, $kparms, \%info);
	    if ($ret != 0)
	    {
		my $err = Authen::Digipass::AAL2GetErrorMsg($ret);
		print STDERR "Could not GetTokenInfo for Digipass $serial: $err\n";
	    }
	    else
	    {
		print "Detailed information for Digipass $serial:\n";
		my $key;
		foreach $key (sort keys %info)
		{
		    print "$key: $info{$key}\n";
		}
	    }
	}
	else
	{
	    print STDERR "Could not get Digipass '$serial': no such record in database\n";
	}
    }
}

#####################################################################
# Take a serial number, maybe append the default application name
sub normaliseSerial
{
    my ($s) = @_;

    $s .= $requestapp unless length $s > 10;
    return $s;
}

#####################################################################
#####################################################################
#####################################################################
# Here is where all the database dependent code goes. Everything 
# above does not care what type of database (SQL or LDAP) we are connected to

#####################################################################
# Connect to the selected database
# Return undef if failed
sub db_connect
{
    return $main::opt_ldap ? ldap_connect() : sql_connect();
}

#####################################################################
# Insert a new record, or replace an existing one
sub db_insert_or_replace
{
    return $main::opt_ldap ? ldap_insert_or_replace(@_) : sql_insert_or_replace(@_);
}

#####################################################################
# Find token data in database from the token serial number and return it
# Return (unique_key, token_data)
# Return undef if not found
sub db_get
{
    return $main::opt_ldap ? ldap_get(@_) : sql_get(@_);
}

#####################################################################
# Update token data
sub db_update
{
    return $main::opt_ldap ? ldap_update(@_) : sql_update(@_);
}

#####################################################################
# Iterate a function of all tokens in the database
# The iterator is called like fn(serial, user, tokentype, algotype, data)
sub db_iterate
{
    return $main::opt_ldap ? ldap_iterate(@_) : sql_iterate(@_);
}

#####################################################################
# Deassign any and all tokens that may be assigned to $user
sub db_deassign
{
    return $main::opt_ldap ? ldap_deassign(@_) : sql_deassign(@_);
}

#####################################################################
# Deassign any and all tokens that may be assigned to $user
sub db_assign
{
    return $main::opt_ldap ? ldap_assign(@_) : sql_assign(@_);
}

#####################################################################
sub sql_connect
{
    require DBI;
	
    print "Connecting to SQL database with $dbsource, $dbusername, $dbauth\n" 
	if $main::opt_v;
    $dbh = DBI->connect($dbsource, $dbusername, $dbauth, 
			{PrintError => 0
			 });
    print STDERR "Could not connect to SQL database $dbsource: $DBI::errstr\n"
	unless $dbh;
    return $dbh;
}
    
#####################################################################
sub sql_insert_or_replace
{
    my ($serial, $type, $algo_type, $data) = @_;

    return 1 if $main::opt_n;

    # Now try to insert into the database
    # Radiator does not require  ALGO_TYPE anymore.
    my $q = "insert into $table (DIGIPASS, DP_TYPE, ALGO_TYPE, DP_DATA) values ('$serial', '$type', '$algo_type', '$data')";
    print "Running insert query: $q\n" if $main::opt_v;
    if (!$dbh->do($q))
    {
	my $err = $dbh->errstr;
	
	# Insert failed
	if ($main::opt_f)
	{
	    # Maybe force an update if there is already an entry for this digipass
	    $q = "select DIGIPASS from $table where DIGIPASS = '$serial'";
	    print "Insert failed but -f option is on, looking for existing record to update with $q\n" if $main::opt_v;
	    my ($dummy) = $dbh->selectrow_array($q);
	    if (defined $dummy)
	    {
		# Radiator does not require  ALGO_TYPE anymore.
		$q = "update $table set DP_TYPE='$type', ALGO_TYPE='$algo_type', DP_DATA='$data' where DIGIPASS = '$serial'";
		print "Updating existing SQL record with: $q\n", if $main::opt_v;
		next if $main::opt_n;
		if (!$dbh->do($q))
		{
		    # The update failed too, bomb out
		    my $err = $dbh->errstr;
		    print STDERR "update of SQL database record for '$serial' failed: $err\n";
		    return;
		}
	    }
	    else
	    {
		my $err = $dbh->errstr;
		print STDERR "select into SQL database for Digipass '$serial' failed: $err\n";
		return;
	    }
	}
	else
	{
	    my $err = $dbh->errstr;
	    print STDERR "insert into SQL database for Digipass '$serial' failed: $err\n";
	    return;
	}
    }
    # Success
    return 1;
}

#####################################################################
sub sql_get
{
    my ($serial) = @_;

    my $q = "select DP_DATA from $table where DIGIPASS = '$serial'";
    print "Looking for Digipass to get: $q\n" if $main::opt_v;
    my ($data) = $dbh->selectrow_array($q);
    return ($serial, $data);
}

#####################################################################
sub sql_update
{
    my ($key, $data) = @_;

    return 1 if $main::opt_n;

    # For SQL, $key is the serial number
    my $q = "update $table set DP_DATA = '$data' where DIGIPASS = '$key'";
    print "Running update query: $q\n", if $main::opt_v;
    next if $main::opt_n;
    if (!$dbh->do($q))
    {
	# The update failed too, bomb out
	my $err = $dbh->errstr;
	print STDERR "update of SQL database record for '$key' failed: $err\n";
	return;
    }
    return 1;
}

#####################################################################
sub sql_iterate
{
    my ($fn) = @_;

    my $q = "select DIGIPASS, USER_ID, DP_TYPE, ALGO_TYPE, DP_DATA from $table";
    my $sth =  $dbh->prepare($q);
    if (!$sth)
    {
	my $err = $dbh->errstr;
	print STDERR "Could not prepare $q: $err\n";
	return;
    }
    if (!$sth->execute())
    {
	my $err = $dbh->errstr;
	print STDERR "Could not execute $q: $err\n";
	return;
    }
    my @ret;
    while (@ret = $sth->fetchrow_array)
    {
	&$fn(@ret);
    }
}

#####################################################################
sub sql_deassign
{
    my ($name) = @_;

    my $q =  "update $table set USER_ID = NULL where USER_ID = '$name'";
    print "Running deassign query: $q\n", if $main::opt_v;
    if (!$dbh->do($q))
    {
	# The deassign failed
	my $err = $dbh->errstr;
	print STDERR "Could not deassign other tokens already assigned to $name: $err\n";
    }
}

#####################################################################
sub sql_assign
{
    my ($serial, $name) = @_;

    my $qname = defined $name ? $dbh->quote($name) : 'NULL';

    # Write the updated data back to the database
    my $q = "update $table set USER_ID = $qname where DIGIPASS = '$serial'";
    print "Running assign query: $q\n" if $main::opt_v;
    return if $main::opt_n;
    if (!$dbh->do($q))
    {
	# The update failed too, bomb out
	my $err = $dbh->errstr;
	print STDERR "update of database record for '$serial' failed: $err\n";
    }
}

#####################################################################
#####################################################################
#####################################################################
# LDAP support

#####################################################################
sub ldap_connect
{
    require Net::LDAP;
    import  Net::LDAP qw(LDAP_SUCCESS LDAP_ALREADY_EXISTS);

    print "Connecting to LDAP database at $ldaphost:$ldapport, base DN: $ldapbasedn\n"
	if $main::opt_v;
    $ld = new Net::LDAP($ldaphost,
			port => $ldapport,
			version => $ldapversion);
    print STDERR "Could not connect to LDAP database at $ldaphost:$ldapport\n"
	unless $ld;
    $ld->debug(255) if $ld && $main::opt_d;
    
    print "Binding LDAP connection with $ldapauthdn, $ldapauthpw\n"
	if $main::opt_v;
    my $result = $ld->bind(dn => $ldapauthdn, password => $ldapauthpw);
    if (!$result || $result->code())
    {
	ldap_error($result, "Could not bind LDAP connection with $ldapauthdn, $ldapauthpw");
	return;
    }
    return $ld;
}

#####################################################################
sub ldap_insert_or_replace
{
    my ($serial, $type, $algo_type, $data) = @_;

    my $dn = "oscDigipassTokenSerial=$serial,$ldapbasedn";

    my $attributes = [
				    oscDigipassTokenSerial => $serial,
				    oscDigipassTokenType => $type,
				    oscDigipassTokenAlgoType => $algo_type,
        oscDigipassTokenData => $data
        ];

    if (%ldapvalues) {
        foreach my $attr (keys(%ldapvalues)) {
            push (@$attributes,  $attr => $ldapvalues{$attr});
        }
    }

    my @add_attributes = @$attributes;
    push(@add_attributes, objectclass => \@objectClasses);

    my $result = $ld->add($dn,
                          attrs => \@add_attributes
        );

    if ($result && $result->code() == &LDAP_ALREADY_EXISTS && $main::opt_f)
    {
	print "Insert failed but -f option is on, looking for existing record to update with DN $dn\n" if $main::opt_v;
	$result = $ld->modify($dn,
                              replace => $attributes
            );
    }

    if (!$result || $result->code())
    {
	ldap_error($result, "Could not add or replace LDAP record for $dn");
	return;
    }
    return 1;
}

#####################################################################
sub ldap_get
{
    my ($serial) = @_;

    my $filter = "(oscDigipassTokenSerial=$serial)";
    print "LDAP search in base '$ldapbasedn' with filter '$filter' and scope '$ldapscope'\n" 
	if $main::opt_v;
    my $result = $ld->search
	(base   => $ldapbasedn,
	 scope  => $ldapscope,
	 filter => $filter);

    if (!$result || $result->code())
    {
	ldap_error($result, "LDAP search failed");
	return;
    }

    my $entry = $result->entry(0);
    return unless $entry;
    return ($entry->dn(), $entry->get_value('oscDigipassTokenData'));
}

#####################################################################
sub ldap_update
{
    my ($key, $data) = @_;

    return 1 if $main::opt_n;

    my $result = $ld->modify($key, replace => {'oscDigipassTokenData', $data});

    # $result is an object of type Net::LDAP::Search
    if (!$result || $result->code())
    {
	ldap_error($result, "Update of LDAP database record for '$key' failed");
	return;
    }
    return 1;
}

#####################################################################
sub ldap_iterate
{
    my ($fn) = @_;

    my $filter = '(objectclass=oscDigipassToken)';
    my $result = $ld->search
	       (base => $ldapbasedn,
		scope => 'sub',
		filter => $filter);

    if (!$result || $result->code())
    {
	ldap_error($result, "LDAP search failed");
	return;
    }
    # Iterate over all the records we found
    my $i = 0;
    my $entry;
    while ($entry = $result->entry($i++))
    {
	&$fn($entry->get_value('oscDigipassTokenSerial'),
	     $entry->get_value('oscDigipassTokenAssignedTo'),
	     $entry->get_value('oscDigipassTokenType'),
	     $entry->get_value('oscDigipassTokenAlgoType'),
	     $entry->get_value('oscDigipassTokenData'));
    }
}

#####################################################################
sub ldap_deassign
{
    my ($name) = @_;

    my $filter = "(oscDigipassTokenAssignedTo=$name)";
    my $result = $ld->search
	       (base => $ldapbasedn,
		scope => 'sub',
		filter => $filter);

    if (!$result || $result->code())
    {
	ldap_error($result, "LDAP search failed");
	return;
    }

    # Iterate over all the records we found
    my $i = 0;
    my $entry;
    while ($entry = $result->entry($i++))
    {
	my $dn = $entry->dn();
	my $mresult = $ld->modify
	    ($dn,
	     delete => ['oscDigipassTokenAssignedTo']);
	if (!$mresult || $mresult->code())
	{
	    ldap_error($mresult, "LDAP deassign of $dn failed");
	    return;
	}
    }
    return 1;
}

#####################################################################
sub ldap_assign
{
    my ($key, $name) = @_;

    return 1 if $main::opt_n;

    my $result = $ld->modify($key, replace => {'oscDigipassTokenAssignedTo', $name});

    # $result is an object of type Net::LDAP::Search
    if (!$result || $result->code())
    {
	ldap_error($result, "Update of LDAP database record for '$key' failed");
	return;
    }
    return 1;
}


#####################################################################
# Print an LDAP error message to STDERR
sub ldap_error
{
    my ($result, $s) = @_;

    my $code = $result ? $result->code() : -1;
    my $err = Net::LDAP::Util::ldap_error_name($code);
    print STDERR $s . ': ' . $err . "\n";
    return;
}

=head1 NAME

digipass.pl - command line application for manipulating Vasco Digipass token data
in SQL or LDAP databases.

=head1 SYNOPSIS

SQL:

 digipass.pl -dbsource dbi:mysql:radius -dbusername mikem -dbauth fred import demo.dbx
 digipass.pl -dbsource dbi:mysql:radius -dbusername mikem -dbauth fred assign '0097123456APPL 1' mikem
 digipass.pl -dbsource dbi:mysql:radius -dbusername mikem -dbauth fred info '0097123456APPL 1'

LDAP:

 digipass.pl -ldap -D 'cn=Manager, dc=example, dc=com' -w secret -b 'dc=example, dc=com' import demo.dbx
 digipass.pl -ldap -D 'cn=Manager, dc=example, dc=com' -w secret -b 'dc=example, dc=com' assign '0097123456APPL 1' mikem
 digipass.pl -ldap -D 'cn=Manager, dc=example, dc=com' -w secret -b 'dc=example, dc=com' info '0097123456APPL 1'

=head1 DESCRIPTION

This application can be used to administer Vasco Digipass token data 
in an SQL or LDAP database. The token data can then be used to authenticate users 
with Radiator's AuthBy SQLDIGIPASS or AUthBy LDAPDIGIPASS modules.

It can be used to import, assign, examine, reset and perform other operations on 
your token data.

digipass.pl can be used with either an SQL or LDAp database. If you use the -ldap 
command line flag, digipass.pl will attempt to conent to an LDAP dtabase, else it 
will attemtp to conent to an SQL database. You can use command line flags to control
where and how to connect to either type of database.

digipass.pl implements a set of commands for acting on tokens in the database.

=head1 COMMANDS

=head2 import [-f] [-importkey xxxxxxx] [-app appname] filename.dpx

Imports token data from a token data file and inserts it into the database.
For each token or batch of tokens you purchaase from Vaso, they will supply 
a token data file, whcih contains details of all the tokens you have purchased.
The file has a '.dpx' extension. It must be imported into the database anbd assigned
to a user before AuthBy SQLDIGIPASS or AUthBy LDAPDIGIPASS can authenticate users
with those tokens.

=head2 list

Prints a list details for all tokens in the database, one per line to
stdout. The information is in 5 columns:

 serialno assigned-to token-type algorithm-type token-data

=head2 reset serialno .....

Reset some Digipass data block couters and values for the tokens
specified. Resets inteernal error counters for each token.

=head2 resetstaticpassword serialno ....

Indicates that the user(s) will have to define a new static password (PIN) for the
token(s) the next time they log in (provided the token supports static passwords).

=head2 changestaticpassword serialno newpin

Sets a new static password (PIN) for the token (provided the token supports
static passwords).

=head2 verify serialno tokencode

Checks that the token verification (password) works for the token. Tokencode
is the token currently displayed on the specified token, possibly prefixed by
the current static password (PIN). You can use this to test that the token is
working correctly, and that the token data in the database is correct and valid.

=head2 assign serialno [username]

=head2 unlock serialno tokencode

=head2 info serialnumber ....

=head2 help

Display some basic usage and help text and exit

=head1 COMMAND LINE FLAGS

=head2 GENERIC

=head3 -h

Display some basic usage and help text and exit

=head3 -v

Print verbose information about what digipass.pl is doing.

=head3 -d

Print debugging information about the databse connection and transactions

=head3 -n

Don't actually change the database.

=head3 -importkey nnnnnnn

Specifies a non-standard import key for importing token data from a token data
file.  Defaults to '11111111111111111111111111111111', which is the standard
key used in most token data files. Use this flag if your tokan data file has a
non-standard import key. Vasco will tell you what the value of this flag
should be if you need it.

=head3 -app appname

During an import operation, if there are mutiple application names available, this 
flag specifies which token application to import. For a given token, there
may be several applicaiotns in the token data file, for example for RO 
(response only) or CR (challenge-response). Use this flag to spcify which application
to import.

=head3 -f

During an import operation, if the token already exists in the database, use
this flag to force digipass.pl to overwrite the existing token data. If the
token has been assigned to a user, the assignment will not be lost.

=head3 -syncwindow nn

Specifies the synchronisation time window in hours to be used during the
verify comand.  Defaults to 6 hours.

=head2 SQL

=head3 -dbsource dbi:dbname:table

Specifies the DBI data source, which determines which database driver to use
and which database to connect to. Depending on the database driver, other
database connection parameters may also be specified.  Defaults to
'dbi:mysql:radius', which will almost certainly have to be changed. See 'man
DBI' for more details on how to use DBI data source.

=head3 -dbusername sqlusername

Specifies the name of the SQL user to be used to connect to the SQL database.
Must be an SQL username with sufficient priveleges to insert, update and
delete records in the database table specified by -table. Defaults to 'mikem'.

=head3 -dbauth sqluserpassword

Specifies the password for the users specified by -dbusername. Defaults to 'fred'.

=head3 -table tablename

Specifies the name of the database table that contains Digipass token data. 
Defaults to 'TBL_VASCODP', whcih is compativle with the defaults used
by AuthBy SQLDIGIPASS.

=head2 LDAP

=head3 -ldap

Specifies that digipass.pl is to connect to an LDAP database instead of an 
SQL databse. Defaults to SQL.

=head3 -D ldap-connection-DN

Specifies the DN of the user to connect to the LDAP database. It must be the 
DN of an LDAP user sufficiently priveleged to access and change the token data in the
BaseDN. The user's password must be specified with -w. Defaults to 
'cn=Manager, dc=example, dc=com' which will almost certainly have to be changed.

=head3 -w ldap-connection-secret

Specifies the secaret password to be used to connect to the LDAP server. 
the password is the password for the LDAP user specified by the -D flag.
Defaults to 'secret' which will almost certainly have to be changed.

=head3 -p port

Specifies theport number of the LDAP server. Defaults to 389.

=head3 -host hostname

Specifies the name or address of the LDAP server. Defaults to localhost.

=head3 -b BaseDN

Specifies the Base DN, the abse of all LDAP token searches and operations.
It is the area in the LDAP database where all token data is stored. 
Defaults to 'dc=example, dc=com', which you will certainly want to change
to suit your organisation:

 -b 'ou=DigipassTokens,dc=yourcompany,dc=com'

=head3 -P 2|3

Specifies the LDAP protocol version to use. Defaults to 3
=head3 -s scope

Specifies the search scope that will be used to find tokens in the LDAP database.
Permitted values for scope are:

 base
  Search only the baseDN object.

 one
  Search the entries immediately below the base object.

 sub
  Search the whole tree below (and including) the base object. This is the default.

=head1 ENVIRONMENT

You can preset some or all command line flags for digipass.pl using the
DIGIPASS_PL_ARGS environment variable. In this example, the -D, -w and -b flags
will be automatically set in the environment when digipass.pl runs:

export DIGIPASS_PL_ARGS='-D cn=admin,dc=xyz,dc=com -w mysecret -b ou=People,dc=xyz,dc=com'
digipass.pl list

=head1 SQL DATABASES

Before you can use digipass.pl with an SQL database, you must create a
suitable username and password to use to connect to the database, and create
an SQL table to store the token data. A Sample table definition for MySQL can
be found in create-mysql.sql in the Authen-Digipass distribution or in
goodies/create*.sql in the Radiator distribution. The examples work with
digipass.pl and with Radiator example configuration in goodies/digipass.cfg

=head1 LDAP DATABASES

Before you can use digipass.pl with an LDAP database, you must configure a
suitable data schema into your LDAP database server. A sample schema for
OpenLDAP can be found in goodies/radiator-ldap.schema in the Radiator
distribution.

You or your LDAP database administrator will probably want to define a
specific area in the LDAP database where the Digipass token data will be
stored. This is the BaseDN, and you will need to specify this as the -b flag
to digipass.pl, and configure it into BaseDN in your AuthBy LDAPDIGIPASS
clause in Radiator. A typical BaseDN for a real company might be:

 ou=DigipassTokens,dc=yourcompany,dc=com

=head1 SEE ALSO

VACMAN Controller Programmer's Guide (www.vasco.com)

Radiator Radius Server (www.open.com.au/radiator)

=head1 AUTHOR

Mike McCauley, E<lt>mikem@open.com.auE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright 2004-2006 Open System Consultants Pty Ltd
The source code for this wrapper is subject to licensing from Open
System Consultants. Prebuilt binary distributions contain parts that
are Copyright (C) Vasco, and subject to Vasco licensing.

