# Digipass.pm
#
# Encapsulation of the Vasoc Digipass Vacamna Controller 
# AAL2 token authentication library
#
# Author: Mike McCauley (mikem@open.com.au)
# Copyright (C) 2004 Open System Consultants
# $Id: Digipass.pm,v 1.10 2014/11/25 13:26:24 hvn Exp hvn $

package Authen::Digipass::KernelParms;

# This structure is required by all Digipass calls, and controls behaviour of the library
# during the call
# See Digipass docs for descriptions of each configurable parameter
sub new
{
    my ($class, @args) = @_;

    my $self = {
	ITimeWindow       => 100,         # 2 to 1000 TimeSteps
	STimeWindow       => 24,          # 2 to 500 TimeSteps
	DiagLevel         => 0,           # 0 to 3
	GMTAdjust         => 0,           # -86400 to 86400 seconds
	CheckChallenge    => 1,           # 0 to 4
	IThreshold        => 0,           # 0 to 255
	SThreshold        => 0,           # 0 to 255
	ChkInactDays      => 0,           # 0 to 1024
	DeriveVector      => 0,           # 0 to 0x7fffffff
	SyncWindow        => 6,           # 1 to 60
	OnLineSG          => 0,           # 0 to 2 Level of online signature
	EventWindow       => 100,         # 10 to 1000
	HSMSlotId         => 0,           # 0 to 60
	StorageKeyId      => 0,           # 0 to 0xffffffff
	TransportKeyId    => 0x7fffff,    # 1 to 0xffffffff
	StorageDeriveKey1 => 0,           # 0 to 0xffffffff
	StorageDeriveKey2 => 0,           # 0 to 0xffffffff
	StorageDeriveKey3 => 0,           # 0 to 0xffffffff
	StorageDeriveKey4 => 0,           # 0 to 0xffffffff
	@args,
    };
    bless $self, $class;
    return $self;
}

package Authen::Digipass;

use 5.006;
use strict;
use warnings;
use Carp;

require Exporter;
use AutoLoader;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Authen::Digipass ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	AAL2SDK_H
	AES
	CHAP
	C_TYPES_REDECLARATION
	DES
	DPRSP
	HMAC
	INT_VALUE
	KRB5
	LANMAN
	LAST_TIME_SHIFT
	LAST_TIME_USED
	MD4
	MD5
	MSCHAP
	MSCHAP2
	NTLM
	NTLM2
	NTLM2DOMAIN
	NTLM2USER
	PIN_CH_FORCED
	PIN_CH_ON
	PIN_LEN
	PIN_MIN_LEN
	PIN_SUPPORTED
	PRF
	SHA_1
	STATIC_PWD_SUPPORTED
	TIME_BASED_ALGO
	TOKEN_MODEL
	UNLOCK_SUPPORTED
	USE_COUNT
	WINHASH
	XOR
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	AAL2SDK_H
	AES
	CHAP
	C_TYPES_REDECLARATION
	DES
	DPRSP
	HMAC
	INT_VALUE
	KRB5
	LANMAN
	LAST_TIME_SHIFT
	LAST_TIME_USED
	MD4
	MD5
	MSCHAP
	MSCHAP2
	NTLM
	NTLM2
	NTLM2DOMAIN
	NTLM2USER
	PIN_CH_FORCED
	PIN_CH_ON
	PIN_LEN
	PIN_MIN_LEN
	PIN_SUPPORTED
	PRF
	SHA_1
	STATIC_PWD_SUPPORTED
	TIME_BASED_ALGO
	TOKEN_MODEL
	UNLOCK_SUPPORTED
	USE_COUNT
	WINHASH
	XOR
);

our $VERSION = '1.12';

sub AUTOLOAD {
    # This AUTOLOAD is used to 'autoload' constants from the constant()
    # XS function.

    my $constname;
    our $AUTOLOAD;
    ($constname = $AUTOLOAD) =~ s/.*:://;
    croak "&Authen::Digipass::constant not defined" if $constname eq 'constant';
    my ($error, $val) = constant($constname);
    if ($error) { croak $error; }
    {
	no strict 'refs';
	# Fixed between 5.005_53 and 5.005_61
#XXX	if ($] >= 5.00561) {
#XXX	    *$AUTOLOAD = sub () { $val };
#XXX	}
#XXX	else {
	    *$AUTOLOAD = sub { $val };
#XXX	}
    }
    goto &$AUTOLOAD;
}

require XSLoader;
XSLoader::load('Authen::Digipass', $VERSION);

# Preloaded methods go here.

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Authen::Digipass - Perl extension for Vasco Digipass Vacman Controller AAL2 authentication library

=head1 SYNOPSIS

  use Authen::Digipass;
  my $kparms = Authen::Digipass::KernelParms->new(ITimeWindow => 100, IThreshold => 0);
  my ($handle, $appl_count, $appl_names, $token_count);
  Authen::Digipass::AAL2DPXInit($handle, 'demo.dpx', '11111111111111111111111111111111', $appl_count, $appl_names, $token_count);
  my ($serial, $type, $mode, $data);
  Authen::Digipass::AAL2DPXGetToken($handle, $kparms, 'APPL 1      ', $serial, $type, $mode, $data);
  Authen::Digipass::AAL2DPXClose($handle);
  if (Authen::Digipass::AAL2VerifyPassword($data, $kparms, $tokencode, undef) == 0)
  {
    # Authentication successful
  }
  
=head1 ABSTRACT

  Provides a complete encapsulation of the 
  Vasco Digipass Vacman Controller AAL2 authentication library 

=head1 DESCRIPTION

Provides functions for importing, administering and validating Vasco
tokens.

Also includes a command line utility (digipass.pl) for importing token
data into an SQL database, assigning tokens to users, verifying
passwords and getting token information. The database table is
compatible with the Radiator AuthBy DIGIPASS native Digipass
authentication module.

=head2 EXPORT

None by default.

=head2 Exportable constants

  AAL2SDK_H
  AES
  CHAP
  C_TYPES_REDECLARATION
  DES
  DPRSP
  HMAC
  INT_VALUE
  KRB5
  LANMAN
  LAST_TIME_SHIFT
  LAST_TIME_USED
  MD4
  MD5
  MSCHAP
  MSCHAP2
  NTLM
  NTLM2
  NTLM2DOMAIN
  NTLM2USER
  PIN_CH_FORCED
  PIN_CH_ON
  PIN_LEN
  PIN_MIN_LEN
  PIN_SUPPORTED
  PRF
  SHA_1
  STATIC_PWD_SUPPORTED
  TIME_BASED_ALGO
  TOKEN_MODEL
  UNLOCK_SUPPORTED
  USE_COUNT
  WINHASH
  XOR



=head1 SEE ALSO

VACMAN Controller Programmer's Guide (www.vasco.com)

Radiator Radius Server (www.open.com.au/radiator)

=head1 AUTHOR

Mike McCauley, E<lt>mikem@open.com.auE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright 2004 Open System Consultants Pty Ltd
The source code for this wrapper is subject to licensing from Open
System Consultants. Prebuilt binary distributions contain parts that
are Copyright (C) Vasco, and subject to Vasco licensing.

=cut
